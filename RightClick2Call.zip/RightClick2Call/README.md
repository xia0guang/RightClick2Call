#Right Click 2 Call(with Facetime)
### A chrome extension for call

This is repositiory for my first Chrome Extension, which is a extension that enable user click to call with Facetime on Mac

